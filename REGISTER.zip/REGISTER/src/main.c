/* 
 Projeto: REGISTER
 Autor: Lucas Gabriel e Gusthavo H. S. Rodrigues
 Data de criação: 14/10/2025
 Descrição: Estrutura inicial do projeto integrador.
*/

#include <stdio.h>

int main(void) {
    printf("Iniciando o Projeto Integrador...\n");
    return 0;
}